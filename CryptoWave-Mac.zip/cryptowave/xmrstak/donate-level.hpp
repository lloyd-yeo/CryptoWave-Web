#pragma once
constexpr double fDevDonationLevel = 0.0;
